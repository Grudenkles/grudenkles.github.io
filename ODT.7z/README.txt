Copy to root of C drive

Admin CMD

Download using (setup.exe /download ASConfig.xml)

Install using (setup.exe /configure "ASConfig.xml")